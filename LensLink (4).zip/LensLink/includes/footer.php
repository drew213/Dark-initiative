<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.0
    </div>
    Copyright &copy; <?php echo date("Y");?> <strong> IT Sky Solutions Limited </strong>
  </footer>