
<head>
<style type="text/css">
.auto-style1 {
	text-align: center;
}
</style>
</head>

<footer class="auto-style1">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.0
    </div>
    Copyright &copy; <?php echo date("Y");?> <strong> IT Sky Solutions Limited </strong>
  </footer>